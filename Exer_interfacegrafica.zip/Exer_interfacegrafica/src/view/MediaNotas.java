package view;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class MediaNotas extends JFrame{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JLabel lbDisciplina,lbNota1,lbNota2,lbNota3,lbNota4;
	private JTextField txDisciplina,txNota1,txNota2,txNota3,txNota4;
	private JButton btExibir;
	
	       public MediaNotas() {
	
		   setTitle("Media do aluno");
		   setSize(400,600);                        //largura e altura
/*setDev*/ setDefaultCloseOperation(EXIT_ON_CLOSE);//encerrar o programa
/*setLoc*/ setLocationRelativeTo(null);           //centralizar a janela
		   setResizable(false);                  //janela de tamanho fixo
		   setLayout(null);                     //sem gerenciador de layout
		   getContentPane().setBackground(Color.LIGHT_GRAY);//cor de fundo
		   
		   lbDisciplina=new JLabel();
		   lbDisciplina.setText("Nome da disciplina:");
		   lbDisciplina.setBounds(50,100,140,30); 
		   add(lbDisciplina);   //deixando o nome visivel na janela
		   
		   txDisciplina = new JTextField();
		   txDisciplina.setBounds(175,100,140,30);		
		   add(txDisciplina);
		   
		   
		   lbNota1=new JLabel();
		   lbNota1.setText("Digite a primeira nota:");
		   lbNota1.setBounds(50, 140, 140, 30);
		   add(lbNota1);
		   
		   txNota1=new JTextField();
		   txNota1.setBounds(175, 140, 140, 30);
		   add(txNota1);
		   
		   
		   lbNota2=new JLabel();
		   lbNota2.setText("Digite a segunda nota:");
		   lbNota2.setBounds(50, 180, 140, 30);
           add(lbNota2);
           
           txNota2=new JTextField();
           txNota2.setBounds(175, 180, 140, 30);
           add(txNota2);
           
           
           lbNota3=new JLabel();
		   lbNota3.setText("Digite a terceira nota:");
		   lbNota3.setBounds(50, 220, 140, 30);
		   add(lbNota3);
		   
		   txNota3=new JTextField();
		   txNota3.setBounds(175, 220, 140, 30);
		   add(txNota3);
		   
		   
		   lbNota4=new JLabel();
		   lbNota4.setText("Digite a quarta nota:");
		   lbNota4.setBounds(50, 260, 140, 30);
		   add(lbNota4);
		   
		   txNota4=new JTextField();
		   txNota4.setBounds(175, 260, 140, 30);
		   add(txNota4);
		   
		
	        btExibir = new JButton("Calcular Média");
	        btExibir.setBounds(175, 320, 150, 40);
	        btExibir.setForeground(Color.BLACK);
	        btExibir.setBackground(Color.PINK);

	      
	        btExibir.addActionListener(new ActionListener() {
	         @Override
	         public void actionPerformed(ActionEvent e) {
	         String Disciplina = txDisciplina.getText();
	         double Nota1=Double.parseDouble(txNota1.getText());
	         double Nota2=Double.parseDouble(txNota2.getText());
	         double Nota3=Double.parseDouble(txNota3.getText());
	         double Nota4=Double.parseDouble(txNota4.getText());

	         double media = CalcularMedia.calcular(Nota1, Nota2, Nota3, Nota4);

	         JOptionPane.showMessageDialog(null,"Disciplina: " +Disciplina+"\nMédia: "+ media);
	         } 
	         });

	        add(btExibir);

	        setVisible(true);
	      }

	    public static void main(String[] args) {
	        new MediaNotas();
	    }
	}
		    
 
