package view;

public class CalcularMedia {
	public static double calcular(double Nota1,double Nota2,double Nota3,double Nota4) {
    return (Nota1+Nota2+Nota3+Nota4)/4;
  }
}
