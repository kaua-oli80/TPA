package Padrao;

import view.MediaNotas;

public class Aplicacao {

	public static void main(String[] args) {
		new MediaNotas();
   }
}

